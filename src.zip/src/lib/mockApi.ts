import type { GenerateFlashcardsResponseDTO, FlashcardDTO, FlashcardGenerationLogDTO } from "@/types";

// Mock odpowiedzi API dla generowania fiszek
export const mockGenerateFlashcardsResponse = (
  userInput: string,
  simulateError = false,
  errorType?: "network" | "timeout" | "server" | "validation"
): Promise<GenerateFlashcardsResponseDTO> => {
  return new Promise((resolve, reject) => {
    // Symulacja opóźnienia odpowiedzi od 1 do 3 sekund
    const delay = Math.floor(Math.random() * 2000) + 1000;

    setTimeout(() => {
      // Jeśli symulujemy błąd, odrzucamy promise z odpowiednim komunikatem
      if (simulateError) {
        switch (errorType) {
          case "network":
            reject(new TypeError("Failed to fetch"));
            break;
          case "timeout":
            reject(new Error("Przekroczono czas oczekiwania. Serwer zajął zbyt dużo czasu na odpowiedź."));
            break;
          case "server":
            reject(new Error("Błąd serwera. Spróbuj ponownie później lub skontaktuj się z administracją."));
            break;
          case "validation":
            reject(new Error("Nieprawidłowe dane wejściowe. Sprawdź wprowadzony tekst."));
            break;
          default:
            reject(new Error("Wystąpił nieznany błąd podczas generowania fiszek."));
        }
        return;
      }

      // Generowanie 5-10 przykładowych fiszek
      const numberOfFlashcards = Math.floor(Math.random() * 5) + 5;
      const mockFlashcards: FlashcardDTO[] = [];

      for (let i = 0; i < numberOfFlashcards; i++) {
        const mockFlashcard: FlashcardDTO = {
          id: `mock-flashcard-${i}`,
          user_id: "mock-user-id",
          front: `Przykładowa przednia strona fiszki ${i + 1} wygenerowana z tekstu: "${userInput.slice(0, 30)}..."`,
          back: `Przykładowa tylna strona fiszki ${i + 1} z dodatkowym wyjaśnieniem i kontekstem.`,
          status: "pending",
          is_ai_generated: true,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
          is_public: false,
          flashcard_generation_logs_id: "mock-log-id",
        };
        mockFlashcards.push(mockFlashcard);
      }

      // Generowanie przykładowego logu generacji
      const mockGenerationLog: FlashcardGenerationLogDTO = {
        id: "mock-log-id",
        user_id: "mock-user-id",
        user_input: userInput,
        number_generated: mockFlashcards.length,
        generation_duration: delay / 1000, // czas w sekundach
        generated_at: new Date().toISOString(),
      };

      // Zwracanie mockowej odpowiedzi API
      resolve({
        flashcards: mockFlashcards,
        log: mockGenerationLog,
      });
    }, delay);
  });
};

// Funkcja pomocnicza do podmieniania prawdziwego API na mocki podczas testów
export const setupMockApi = () => {
  const originalFetch = window.fetch;

  window.fetch = async (input, init) => {
    // Sprawdzamy czy to wywołanie naszego API generowania fiszek
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : "";

    if (url.includes("/api/flashcards/ai") && init?.method === "POST") {
      // Parsujemy dane wejściowe
      const body = init.body ? JSON.parse(init.body.toString()) : {};
      const userInput = body.user_input || "";

      try {
        // Symulujemy sukces w 80% przypadków
        const simulateError = Math.random() > 0.8;
        const errorTypes = ["network", "timeout", "server", "validation"] as const;
        const errorType = errorTypes[Math.floor(Math.random() * errorTypes.length)];

        const response = await mockGenerateFlashcardsResponse(userInput, simulateError, errorType);

        return {
          ok: true,
          status: 200,
          json: async () => response,
        } as Response;
      } catch (error) {
        // Symulujemy błąd HTTP
        return {
          ok: false,
          status: error instanceof TypeError ? 503 : 500,
          json: async () => ({ message: error instanceof Error ? error.message : "Nieznany błąd" }),
        } as Response;
      }
    }

    // W przypadku innych żądań, przekazujemy je do oryginalnego fetch
    return originalFetch(input, init);
  };

  // Funkcja czyszcząca mock po zakończeniu testów
  return () => {
    window.fetch = originalFetch;
  };
};

// Użycie:
// const cleanupMock = setupMockApi();
// ... uruchomienie testów ...
// cleanupMock();
