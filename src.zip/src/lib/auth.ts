// Flag to temporarily bypass authentication during development/testing
export const ignoreAuth = true;
