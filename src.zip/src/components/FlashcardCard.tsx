import { useState } from "react";
import { type FlashcardDTO, type FlashcardStatus } from "@/types";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { CheckCircle, XCircle, Edit, MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface FlashcardCardProps {
  flashcard: FlashcardDTO;
  onStatusChange: (flashcard: FlashcardDTO, status: FlashcardStatus) => Promise<void>;
}

export function FlashcardCard({ flashcard, onStatusChange }: FlashcardCardProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedFront, setEditedFront] = useState(flashcard.front);
  const [editedBack, setEditedBack] = useState(flashcard.back);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Kolory tła karty w zależności od statusu
  const statusColors = {
    accepted: "bg-green-50 dark:bg-green-950/40 border-green-200 dark:border-green-800",
    rejected: "bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800",
    pending: "",
  };

  // Aktualizacja statusu fiszki
  const handleStatusChange = async (status: FlashcardStatus) => {
    await onStatusChange(flashcard, status);
  };

  // Zapisanie edytowanej fiszki
  const handleSaveEdit = async () => {
    setIsSubmitting(true);

    try {
      const response = await fetch(`/api/flashcards/${flashcard.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          front: editedFront,
          back: editedBack,
          status: flashcard.status,
        }),
      });

      if (!response.ok) {
        throw new Error("Nie udało się zaktualizować fiszki.");
      }

      // Zamknięcie dialogu edycji
      setIsEditing(false);

      // Aktualizacja lokalnego stanu fiszki
      const updatedFlashcard = { ...flashcard, front: editedFront, back: editedBack };
      await onStatusChange(updatedFlashcard, updatedFlashcard.status as FlashcardStatus);
    } catch (error) {
      console.error("Błąd podczas aktualizacji fiszki:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      <Card className={`${statusColors[flashcard.status as FlashcardStatus]}`}>
        <CardContent className="pt-6 pb-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Przód:</h3>
              <p className="text-base">{flashcard.front}</p>
            </div>
            <div>
              <h3 className="text-sm font-medium text-muted-foreground mb-1">Tył:</h3>
              <p className="text-base">{flashcard.back}</p>
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-between">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <span>
              Status:{" "}
              {flashcard.status === "accepted"
                ? "Zaakceptowana"
                : flashcard.status === "rejected"
                  ? "Odrzucona"
                  : "Oczekująca"}
            </span>
          </div>
          <div className="flex space-x-2">
            {flashcard.status === "pending" && (
              <>
                <Button variant="outline" size="sm" onClick={() => handleStatusChange("accepted" as FlashcardStatus)}>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Akceptuj
                </Button>
                <Button variant="outline" size="sm" onClick={() => setIsEditing(true)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edytuj
                </Button>
                <Button variant="outline" size="sm" onClick={() => handleStatusChange("rejected" as FlashcardStatus)}>
                  <XCircle className="mr-2 h-4 w-4" />
                  Odrzuć
                </Button>
              </>
            )}
            {flashcard.status !== "pending" && (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => setIsEditing(true)}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edytuj
                  </DropdownMenuItem>
                  {flashcard.status === "accepted" ? (
                    <DropdownMenuItem onClick={() => handleStatusChange("rejected" as FlashcardStatus)}>
                      <XCircle className="mr-2 h-4 w-4" />
                      Odrzuć
                    </DropdownMenuItem>
                  ) : (
                    <DropdownMenuItem onClick={() => handleStatusChange("accepted" as FlashcardStatus)}>
                      <CheckCircle className="mr-2 h-4 w-4" />
                      Akceptuj
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem onClick={() => handleStatusChange("pending" as FlashcardStatus)}>
                    Oznacz jako oczekującą
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            )}
          </div>
        </CardFooter>
      </Card>

      {/* Dialog edycji fiszki */}
      <Dialog open={isEditing} onOpenChange={setIsEditing}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edytuj fiszkę</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Przód fiszki:</h3>
              <Textarea
                value={editedFront}
                onChange={(e) => setEditedFront(e.target.value)}
                rows={3}
                className="resize-y"
              />
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-medium">Tył fiszki:</h3>
              <Textarea
                value={editedBack}
                onChange={(e) => setEditedBack(e.target.value)}
                rows={3}
                className="resize-y"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isSubmitting}>
              Anuluj
            </Button>
            <Button onClick={handleSaveEdit} disabled={isSubmitting || !editedFront.trim() || !editedBack.trim()}>
              {isSubmitting ? "Zapisywanie..." : "Zapisz zmiany"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
