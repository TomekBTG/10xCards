import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2 } from "lucide-react";

interface GenerateFlashcardsFormProps {
  inputText: string;
  onInputChange: (text: string) => void;
  onSubmit: () => void;
  loading: boolean;
  error: string | null;
}

export function GenerateFlashcardsForm({
  inputText,
  onInputChange,
  onSubmit,
  loading,
  error,
}: GenerateFlashcardsFormProps) {
  // Lokalne stany walidacji
  const [validationError, setValidationError] = useState<string | null>(null);
  const minChars = 500;
  const maxChars = 10000;

  // Sprawdzenie długości tekstu przy każdej zmianie
  useEffect(() => {
    if (inputText.length > 0 && inputText.length < minChars) {
      setValidationError(`Tekst jest za krótki. Minimum ${minChars} znaków.`);
      return;
    }

    if (inputText.length > maxChars) {
      setValidationError(`Tekst jest za długi. Maksimum ${maxChars} znaków.`);
      return;
    }

    setValidationError(null);
  }, [inputText]);

  // Obsługa zmiany tekstu
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onInputChange(e.target.value);
  };

  // Obsługa wysłania formularza
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Walidacja przed wysłaniem
    if (!inputText.trim() || validationError) {
      return;
    }

    // Wywołanie onSubmit z rodzica (który wywołuje generateFlashcards z hooka)
    onSubmit();
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Textarea
          placeholder="Wprowadź tekst do analizy i wygenerowania fiszek..."
          value={inputText}
          onChange={handleTextChange}
          rows={8}
          disabled={loading}
          className="resize-y min-h-[200px]"
          aria-describedby="text-validation"
        />

        <div id="text-validation" className="text-sm flex justify-between text-muted-foreground">
          <span>Min. {minChars} znaków</span>
          <span className={inputText.length > maxChars ? "text-destructive" : ""}>
            {inputText.length} / {maxChars} znaków
          </span>
        </div>
      </div>

      {(validationError || error) && (
        <Alert variant="destructive">
          <AlertDescription>{validationError || error}</AlertDescription>
        </Alert>
      )}

      <Button
        type="submit"
        disabled={loading || !!validationError || inputText.length < minChars}
        className="w-full sm:w-auto"
      >
        {loading ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Generowanie fiszek...
          </>
        ) : (
          "Wygeneruj fiszki"
        )}
      </Button>
    </form>
  );
}
