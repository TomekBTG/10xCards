import { useState } from "react";
import type { GenerateFlashcardsResponseDTO, FlashcardDTO, FlashcardGenerationLogDTO } from "@/types";

interface UseGenerateFlashcardsState {
  inputText: string;
  error: string | null;
  loading: boolean;
  flashcards: FlashcardDTO[];
  generationLog: FlashcardGenerationLogDTO | null;
  retryCount: number; // Licznik ponownych prób
}

interface UseGenerateFlashcardsReturn extends Omit<UseGenerateFlashcardsState, "retryCount"> {
  setInputText: (text: string) => void;
  generateFlashcards: () => Promise<void>;
  resetState: () => void;
  retryGeneration: () => Promise<void>; // Dodana funkcja ponowienia próby
}

export function useGenerateFlashcards(): UseGenerateFlashcardsReturn {
  const [state, setState] = useState<UseGenerateFlashcardsState>({
    inputText: "",
    error: null,
    loading: false,
    flashcards: [],
    generationLog: null,
    retryCount: 0,
  });

  // Aktualizacja tekstu wejściowego
  const setInputText = (text: string) => {
    setState((prev) => ({
      ...prev,
      inputText: text,
      error: null,
    }));
  };

  // Resetowanie całego stanu
  const resetState = () => {
    setState({
      inputText: "",
      error: null,
      loading: false,
      flashcards: [],
      generationLog: null,
      retryCount: 0,
    });
  };

  // Funkcja do faktycznego wywołania API z timeout'em
  const callGenerateAPI = async (): Promise<GenerateFlashcardsResponseDTO> => {
    // Ustawienie timeoutu dla żądania - 30 sekund
    const timeoutId = setTimeout(() => {
      throw new Error("Przekroczono czas oczekiwania. Serwer zajął zbyt dużo czasu na odpowiedź.");
    }, 30000);

    try {
      const response = await fetch("/api/flashcards/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ user_input: state.inputText }),
      });

      // Czyszczenie timeoutu po otrzymaniu odpowiedzi
      clearTimeout(timeoutId);

      if (!response.ok) {
        // Szczegółowa obsługa różnych kodów błędów HTTP
        if (response.status === 400) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Nieprawidłowe dane wejściowe. Sprawdź wprowadzony tekst.");
        } else if (response.status === 401 || response.status === 403) {
          throw new Error("Brak uprawnień do generowania fiszek. Zaloguj się ponownie.");
        } else if (response.status === 429) {
          throw new Error("Przekroczono limit zapytań. Spróbuj ponownie za kilka minut.");
        } else if (response.status >= 500) {
          throw new Error("Błąd serwera. Spróbuj ponownie później lub skontaktuj się z administracją.");
        } else {
          const errorData = await response.json();
          throw new Error(errorData.message || "Wystąpił błąd podczas generowania fiszek.");
        }
      }

      return (await response.json()) as GenerateFlashcardsResponseDTO;
    } catch (error) {
      // Czyszczenie timeoutu w przypadku błędu
      clearTimeout(timeoutId);
      throw error;
    }
  };

  // Główna funkcja do generowania fiszek
  const generateFlashcards = async () => {
    // Walidacja przed wywołaniem API
    if (state.inputText.length < 500) {
      setState((prev) => ({
        ...prev,
        error: "Tekst jest za krótki. Minimum 500 znaków.",
      }));
      return;
    }

    if (state.inputText.length > 10000) {
      setState((prev) => ({
        ...prev,
        error: "Tekst jest za długi. Maksimum 10000 znaków.",
      }));
      return;
    }

    // Ustawienie stanu ładowania
    setState((prev) => ({
      ...prev,
      loading: true,
      error: null,
    }));

    try {
      const data = await callGenerateAPI();

      // Aktualizacja stanu po udanym wywołaniu
      setState((prev) => ({
        ...prev,
        loading: false,
        flashcards: data.flashcards,
        generationLog: data.log,
        error: null,
        retryCount: 0, // Resetowanie licznika prób po sukcesie
      }));
    } catch (err) {
      // Szczegółowa obsługa różnych typów błędów
      let errorMessage = "Nieznany błąd podczas generowania fiszek.";

      if (err instanceof Error) {
        errorMessage = err.message;
      } else if (err instanceof TypeError && err.message.includes("NetworkError")) {
        errorMessage = "Brak połączenia z internetem. Sprawdź swoje połączenie i spróbuj ponownie.";
      } else if (err instanceof TypeError && err.message.includes("Failed to fetch")) {
        errorMessage = "Nie można połączyć się z serwerem. Sprawdź swoje połączenie i spróbuj ponownie.";
      }

      // Aktualizacja stanu po błędzie
      setState((prev) => ({
        ...prev,
        loading: false,
        error: errorMessage,
        retryCount: prev.retryCount + 1,
      }));
    }
  };

  // Funkcja do ponowienia próby generowania fiszek
  const retryGeneration = async () => {
    await generateFlashcards();
  };

  // Zwrócenie tylko potrzebnych wartości i funkcji (bez retryCount)
  return {
    inputText: state.inputText,
    error: state.error,
    loading: state.loading,
    flashcards: state.flashcards,
    generationLog: state.generationLog,
    setInputText,
    generateFlashcards,
    resetState,
    retryGeneration,
  };
}
