import { useState } from "react";
import { type FlashcardDTO, type FlashcardGenerationLogDTO, type FlashcardStatus } from "@/types";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FlashcardCard } from "./FlashcardCard";

interface FlashcardsReviewProps {
  flashcards: FlashcardDTO[];
  generationLog: FlashcardGenerationLogDTO;
}

export function FlashcardsReview({ flashcards, generationLog }: FlashcardsReviewProps) {
  const [cardsState, setCardsState] = useState<FlashcardDTO[]>(flashcards);

  // Funkcja do aktualizacji statusu fiszki
  const updateCardStatus = async (flashcard: FlashcardDTO, newStatus: FlashcardStatus) => {
    try {
      const response = await fetch(`/api/flashcards/${flashcard.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          front: flashcard.front,
          back: flashcard.back,
          status: newStatus,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Nie udało się zaktualizować statusu fiszki.");
      }

      // Aktualizacja stanu lokalnego po udanym żądaniu API
      setCardsState((prevCards) =>
        prevCards.map((card) => (card.id === flashcard.id ? { ...card, status: newStatus } : card))
      );
    } catch (error) {
      console.error("Błąd podczas aktualizacji statusu fiszki:", error);
      // Możemy tutaj dodać wyświetlanie powiadomienia o błędzie
    }
  };

  // Obliczanie statystyk fiszek według statusu
  const stats = {
    accepted: cardsState.filter((card) => card.status === "accepted").length,
    rejected: cardsState.filter((card) => card.status === "rejected").length,
    pending: cardsState.filter((card) => card.status === "pending").length,
    total: cardsState.length,
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Wygenerowane fiszki</CardTitle>
          <CardDescription>
            Łączna liczba fiszek: {stats.total} | Zaakceptowane: {stats.accepted} | Odrzucone: {stats.rejected} |
            Oczekujące: {stats.pending}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">
            Wygenerowano {new Date(generationLog.generated_at).toLocaleString()} na podstawie tekstu o długości{" "}
            {generationLog.user_input.length} znaków.
          </p>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {cardsState.map((flashcard) => (
          <FlashcardCard key={flashcard.id} flashcard={flashcard} onStatusChange={updateCardStatus} />
        ))}
      </div>
    </div>
  );
}
