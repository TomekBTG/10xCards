import { GenerateFlashcardsForm } from "@/components/GenerateFlashcardsForm";
import { FlashcardsReview } from "@/components/FlashcardsReview";
import { EmptyState } from "@/components/EmptyState";
import { useGenerateFlashcards } from "@/components/hooks/useGenerateFlashcards";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileTextIcon } from "lucide-react";

export function GenerateFlashcardsView() {
  // Korzystamy z custom hooka do obsługi generowania fiszek
  const {
    inputText,
    error,
    loading,
    flashcards,
    generationLog,
    setInputText,
    generateFlashcards,
    resetState,
    retryGeneration,
  } = useGenerateFlashcards();

  // Obsługa zmiany tekstu wejściowego
  const handleInputChange = (text: string) => {
    setInputText(text);
  };

  // Obsługa wysłania formularza
  const handleSubmit = () => {
    generateFlashcards();
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Instrukcja dla użytkownika */}
      {!inputText && !flashcards.length && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileTextIcon className="h-5 w-5" />
              Instrukcja
            </CardTitle>
            <CardDescription>Jak wygenerować fiszki przy pomocy sztucznej inteligencji</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">1. Wprowadź tekst</h3>
              <p className="text-sm text-muted-foreground">
                Wklej tekst (minimum 500 znaków), na podstawie którego AI wygeneruje fiszki. Mogą to być notatki,
                artykuły, fragmenty książek lub inne materiały edukacyjne.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">2. Wygeneruj fiszki</h3>
              <p className="text-sm text-muted-foreground">
                Kliknij przycisk &quot;Wygeneruj fiszki&quot; i poczekaj na rezultat. Generowanie może zająć do 30
                sekund, w zależności od długości tekstu.
              </p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">3. Przeglądaj i edytuj</h3>
              <p className="text-sm text-muted-foreground">
                Po wygenerowaniu fiszek możesz je przeglądać, akceptować, edytować lub odrzucać. Zaakceptowane fiszki
                zostaną dodane do Twojej kolekcji.
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Formularz */}
      <GenerateFlashcardsForm
        inputText={inputText}
        onInputChange={handleInputChange}
        onSubmit={handleSubmit}
        loading={loading}
        error={error}
      />

      {/* Stan błędu */}
      {error && !loading && inputText && !flashcards.length && (
        <EmptyState
          title="Wystąpił błąd podczas generowania fiszek"
          description={error}
          icon="error"
          action={{
            label: "Spróbuj ponownie",
            onClick: retryGeneration,
          }}
          actionSecondary={{
            label: "Wyczyść formularz",
            onClick: resetState,
          }}
        />
      )}

      {/* Stan sukcesu - wyświetlanie wygenerowanych fiszek */}
      {flashcards.length > 0 && generationLog && (
        <FlashcardsReview flashcards={flashcards} generationLog={generationLog} />
      )}
    </div>
  );
}
