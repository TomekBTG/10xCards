import { Button } from "@/components/ui/button";
import { AlertCircle, RefreshCcw, FileTextIcon } from "lucide-react";

interface EmptyStateProps {
  title: string;
  description?: string;
  icon?: "error" | "empty" | "noResults";
  action?: {
    label: string;
    onClick: () => void;
  };
  actionSecondary?: {
    label: string;
    onClick: () => void;
  };
}

export function EmptyState({ title, description, icon = "empty", action, actionSecondary }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center p-8 text-center rounded-lg border border-dashed border-muted-foreground/25 bg-muted/10">
      <div className="flex h-20 w-20 items-center justify-center rounded-full bg-muted">
        {icon === "error" && <AlertCircle className="h-10 w-10 text-destructive" />}
        {icon === "empty" && <FileTextIcon className="h-10 w-10 text-muted-foreground" />}
        {icon === "noResults" && <RefreshCcw className="h-10 w-10 text-muted-foreground" />}
      </div>

      <h3 className="mt-4 text-lg font-semibold">{title}</h3>

      {description && <p className="mt-2 text-sm text-muted-foreground max-w-md">{description}</p>}

      {action && (
        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <Button onClick={action.onClick}>{action.label}</Button>

          {actionSecondary && (
            <Button variant="outline" onClick={actionSecondary.onClick}>
              {actionSecondary.label}
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
